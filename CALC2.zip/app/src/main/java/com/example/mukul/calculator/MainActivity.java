package com.example.mukul.calculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,bequal,baddittion,bminus,bdivide,bmultiply,bclear;
    int fact=0;
    TextView display1,display2;
    int a,b,c;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b0=(Button)findViewById(R.id.B0);
        b1=(Button)findViewById(R.id.B1);
        b2=(Button)findViewById(R.id.B2);
        b3=(Button)findViewById(R.id.B3);
        b4=(Button)findViewById(R.id.B4);
        b5=(Button)findViewById(R.id.B5);
        b6=(Button)findViewById(R.id.B6);
        b7=(Button)findViewById(R.id.B7);
        b8=(Button)findViewById(R.id.B8);
        b9=(Button)findViewById(R.id.B9);
        bequal=(Button)findViewById(R.id.BEQUALS);
        baddittion=(Button)findViewById(R.id.BADDITTION);
        bminus=(Button)findViewById(R.id.BMINUS);
        bdivide=(Button)findViewById(R.id.BDIVIDE);
        bmultiply=(Button)findViewById(R.id.BMULTIPLY);
        bclear=(Button)findViewById(R.id.BCLEARS);

        display1=(TextView)findViewById(R.id.DISPLAY1);
        display2=(TextView)findViewById(R.id.DISPLAY2);


        b0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s=(String) display1.getText();
                if(s.equals("0"));

                else {
                    s = s + "0";
                }
                display1.setText(s);

            }
        });



        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s=(String) display1.getText();

                    s = s + "1";

                display1.setText(s);
            }
        });




        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s=(String) display1.getText();

                s = s + "2";
                display1.setText(s);

            }
        });








        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s=(String) display1.getText();

                s = s + "3";
                display1.setText(s);

            }
        });









        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s=(String) display1.getText();

                s = s + "4";
                display1.setText(s);

            }
        });









        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s=(String) display1.getText();

                s = s + "5";
                display1.setText(s);

            }
        });









        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s=(String) display1.getText();

                s = s + "6";

                display1.setText(s);
            }
        });









        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s=(String) display1.getText();

                s = s + "7";

                display1.setText(s);
            }
        });








        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s=(String) display1.getText();

                s = s + "8";
                display1.setText(s);

            }
        });






        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                s=(String) display1.getText();

                s = s + "9";
                display1.setText(s);


            }
        });



        baddittion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                String S;

                if(fact!=0)
                {
                    Toast.makeText(getApplicationContext(), "PRESS EQUAL TO FIRST", Toast.LENGTH_SHORT).show();
                }

                else{
                s=(String) display1.getText();
                S=(String) display2.getText();


                    if(S.equals("") && s.equals(""))
                    {Toast.makeText(getApplicationContext(), "NO VALUE ENTERED", Toast.LENGTH_SHORT).show();}

                    else{
                if(S.equals("")){
                    display1.setText("WORKED");
                a=Integer.parseInt(s);

                s = s + "+";
                display2.setText(s);
                display1.setText("");
                    }

                else
                {
                    a=Integer.parseInt(S);

                    S = S + "+";
                    display2.setText(S);
                    display1.setText("");

                }

                fact=1;}}


            }
        });



        bminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                String S;

                if(fact!=0)
                {
                    Toast.makeText(getApplicationContext(), "PRESS EQUAL TO FIRST", Toast.LENGTH_SHORT).show();
                }


                else{
                s=(String) display1.getText();
                S=(String) display2.getText();


                    if(S.equals("") && s.equals(""))
                    {Toast.makeText(getApplicationContext(), "NO VALUE ENTERED", Toast.LENGTH_SHORT).show();}

                    else{
                if(S.equals("")){
                    a=Integer.parseInt(s);

                    s = s + "-";
                    display2.setText(s);
                    display1.setText("");}

                else
                {
                    a=Integer.parseInt(S);

                    S = S + "-";
                    display2.setText(S);
                    display1.setText("");

                }
            fact=2;}}

            }
        });



        bmultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                String S;

                if(fact!=0)
                {
                    Toast.makeText(getApplicationContext(), "PRESS EQUAL TO FIRST", Toast.LENGTH_SHORT).show();
                }

                else{
                s=(String) display1.getText();
                S=(String) display2.getText();

                    if(S.equals("") && s.equals(""))
                    {Toast.makeText(getApplicationContext(), "NO VALUE ENTERED", Toast.LENGTH_SHORT).show();}

                    else{
                if(S.equals("")){
                    a=Integer.parseInt(s);

                    s = s + "X";
                    display2.setText(s);
                    display1.setText("");}

                else
                {
                    a=Integer.parseInt(S);

                    S = S + "X";
                    display2.setText(S);
                    display1.setText("");

                }
                fact=3;}}

            }
        });



        bdivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                String S;

                if(fact!=0)
                {
                    Toast.makeText(getApplicationContext(), "PRESS EQUAL TO FIRST", Toast.LENGTH_SHORT).show();
                }

                else{
                s=(String) display1.getText();
                S=(String) display2.getText();


                    if(S.equals("") && s.equals(""))
                    {Toast.makeText(getApplicationContext(), "NO VALUE ENTERED", Toast.LENGTH_SHORT).show();}
                else{
                if(S.equals("")){
                    a=Integer.parseInt(s);

                    s = s + "/";
                    display2.setText(s);
                    display1.setText("");}

                else
                {
                    a=Integer.parseInt(S);

                    S = S + "/";
                    display2.setText(S);
                    display1.setText("");

                }
                fact=4;}}


            }
        });












        bequal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s;
                String S;
                String result;
                s=(String) display1.getText();
                S=(String) display2.getText();

                if(S.equals("") && s.equals(""))
                {Toast.makeText(getApplicationContext(), "NO VALUE ENTERED", Toast.LENGTH_SHORT).show();}

                    else{
                    if(s.equals(""))
                        b=0;

                    else{
                b=Integer.parseInt(s);}

                if(fact==0)
                {display2.setText(s);a=b;}

                else {
                    if (fact == 1)
                        c = a + b;
                    if (fact == 2)
                        c = (a - b);

                    if (fact == 3)
                        c = a * b;

                    if (fact == 4)
                        c = a / b;


                    result = Integer.toString(c);


                    display2.setText(result);
                    fact = 0;
                }}
                display1.setText("");

            }
        });


        bclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fact=0;
                display1.setText("");
                display2.setText("");
            }
        });








    }
}
